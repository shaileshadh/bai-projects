main = putStrLn "Meep meep!"

